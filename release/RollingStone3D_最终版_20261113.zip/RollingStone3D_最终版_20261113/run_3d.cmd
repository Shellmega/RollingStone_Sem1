@echo off
setlocal
pushd "%~dp0"
if not exist RollingStone3D.exe (
  echo ERROR: RollingStone3D.exe is missing from this package.
  popd
  exit /b 1
)
RollingStone3D.exe %*
set "RS3D_EXIT=%errorlevel%"
popd
exit /b %RS3D_EXIT%